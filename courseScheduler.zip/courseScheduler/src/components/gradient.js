import React, { Component } from 'react';

class Gradient extends Component {
    render() {
        return <div className="gradient"></div>
    }
}

export default Gradient;