module.exports = {
  plugins: {
    'autoprefixer': {},
  }
};
